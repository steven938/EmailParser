import setuptools
setuptools.setup(
	name='email-parser',
	version='1.0',
	author='Steven Chen',
	packages=setuptools.find_packages(),
)